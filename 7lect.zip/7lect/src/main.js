const express = require('express')
const app = express()
const { selectUser } = require("./user");
// We want to create url or API like eg. http://localhost:4000/users

app.get("/users", async (req,res) => {

const list= await selectUser();
res.json(list);

// let obj= {message : "Hello World"};
// res.json(obj);

}); // arrrow func takes 2 args request and response


app.listen(4000, () =>  console.log("Server started.... "));
